import $ from "jquery";
import "materialize-css/dist/js/materialize.min.js";
import "materialize-css/js/dropdown.js";
import "./style.scss";
import "materialize-css/dist/css/materialize.min.css";

import image from "./images/Xia.jpg";

$(".image").attr("src", image);
